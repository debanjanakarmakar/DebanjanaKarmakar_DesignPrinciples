package com.dk.Calculator;

import java.awt.event.ActionListener;
import java.awt.*;
import javax.swing.*;

@SuppressWarnings("serial")
public class CView extends JFrame{
	private JTextField num1=new JTextField(20);
	private JTextField num2=new JTextField(20);
	private JTextField r=new JTextField(20);
	
	private JLabel addition=new JLabel("Add");
	private JLabel subtraction=new JLabel("Sub");
	private JLabel multiply=new JLabel("Mult");
	private JLabel divide=new JLabel("Div");
	
	private Button add=new Button("+");
	private Button sub=new Button("-");
	private Button mul=new Button("*");
	private Button div=new Button("/");
	private Button res=new Button("Res");
	private Button clr=new Button("C");
	
	CView(){

		JPanel ob = new JPanel();

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600, 300);

		ob.setLayout(new GridLayout(10,2));
		ob.add(num1);
		ob.add(num2);
		ob.add(addition);
		ob.add(add);
		ob.add(subtraction);
		ob.add(sub);
		ob.add(multiply);
		ob.add(mul);
		ob.add(divide);
		ob.add(div);
		ob.add(res);
		ob.add(r);
		ob.add(clr);
	
		this.add(ob);
		
	}
	
	public int getNum1(){

		return Integer.parseInt(num1.getText());

	}

	public int getNum2(){

		return Integer.parseInt(num2.getText());

	}

	public int getCalcSolution(){

		return Integer.parseInt(r.getText());

	}

	public void setr(int solution){

		r.setText(Integer.toString(solution));

	}
	public void setnum1(int a)
	{
		num1.setText(Integer.toString(a));
	}
	public void setnum2(int b)
	{
		num2.setText(Integer.toString(b));
	}
	public void addListener(ActionListener listenadd){

		add.addActionListener(listenadd);

	}

	public void subListener(ActionListener listensub){

		sub.addActionListener(listensub);

	}
	public void mulListener(ActionListener listenmul){

		mul.addActionListener(listenmul);

	}
	public void divListener(ActionListener listendiv){

		div.addActionListener(listendiv);

	}
	void calcListener(ActionListener listencalc){

		res.addActionListener(listencalc);

	}

	void clearListener(ActionListener clearListener){

		clr.addActionListener(clearListener);

	}

	void displayErrorMessage(String errorMessage){

		JOptionPane.showMessageDialog(this, errorMessage);

	}
}

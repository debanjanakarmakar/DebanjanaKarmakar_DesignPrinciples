package com.dk.Calculator;

public class Calculator{

	  public static void main(String[] args) 
	  {
	    	
	    	CView view = new CView();
	        
	    	CModel model = new CModel();
	        
	        CController cont = new CController(view,model);
	        
	        view.setVisible(true);
	        
	    }
	
}

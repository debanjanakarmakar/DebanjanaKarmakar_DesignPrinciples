package com.dk.Calculator;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

	public class CController {

		private CView view;
		private CModel model;

		public CController(CView view, CModel model) {
			this.view = view;
			this.model = model;

			this.view.calcListener(new CalculateListener());
			this.view.addListener(new CalculateListener());
			this.view.subListener(new CalculateListener());
			this.view.mulListener(new CalculateListener());
			this.view.divListener(new CalculateListener());
			this.view.clearListener(new CalculateListener());
		}


		class CalculateListener implements ActionListener{

			public void actionPerformed(ActionEvent e) {

				int firstNumber, secondNumber = 0;
				try{

					firstNumber = view.getNum1();
					secondNumber = view.getNum2();

					if(e.getActionCommand()=="+")
					{
						model.addTwoNumbers(firstNumber, secondNumber);
					}
					else if(e.getActionCommand()=="-")
					{
						model.subTwoNumbers(firstNumber,secondNumber);
					}
					else if(e.getActionCommand()=="*")
					{
						model.mulTwoNumbers(firstNumber, secondNumber);
					}
					else if(e.getActionCommand()=="/")
					{
						model.divTwoNumbers(firstNumber, secondNumber);
					}
					else if(e.getActionCommand()=="Res")
					{
						view.setr(model.getResult());
					}
					else if(e.getActionCommand()=="C")
					{
						view.setr(0);
						view.setnum1(0);
						view.setnum2(0);
					}

				}

				catch(NumberFormatException ex){

					System.out.println(ex);

					view.displayErrorMessage("You Need to Enter 2 Integers");

				}

			}

		}


	}
package com.dk.Calculator;


public class CModel {
	private int res;

	public void addTwoNumbers(int firstNumber, int secondNumber){

		res = firstNumber + secondNumber;

	}

	public void subTwoNumbers(int firstNumber, int secondNumber){

		res = firstNumber - secondNumber;

	}

	public void mulTwoNumbers(int firstNumber, int secondNumber){

		res = firstNumber * secondNumber;

	}

	public void divTwoNumbers(int firstNumber, int secondNumber){

		res = firstNumber / secondNumber;

	}


	public int getResult()
	{
		return res;
	}


}

